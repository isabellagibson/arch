#!/bin/bash
ROOT_UID=0
THEME_DIR="/usr/share/grub/themes"
THEME_NAME="sleek"
MAX_DELAY=20

# checking command availability
function has_command() {
    command -v $1 >/dev/null
}

#checking for root access
echo "\nChecking for root access...\n"
if [ "$UID" -eq "$ROOT_UID" ]; then
    # Create themes directory if not exists
    echo "\nChecking for the existence of themes directory...\n"
    [[ -d ${THEME_DIR}/${THEME_NAME} ]] && rm -rf ${THEME_DIR}/${THEME_NAME}
    mkdir -p "${THEME_DIR}/${THEME_NAME}"
    #copy theme
    echo "\nInstalling ${THEME_NAME} theme...\n"
    cp -a ${THEME_NAME}/* ${THEME_DIR}/${THEME_NAME}
    sed -i "s/Grub Bootloader/Hello $(whoami),/g" $THEME_DIR/$THEME_NAME/theme.txt
    #set theme
    echo "\nSetting ${THEME_NAME} as default...\n"
    # Backup grub config
    cp -an /etc/default/grub /etc/default/grub.bak
    grep "GRUB_THEME=" /etc/default/grub 2>&1 >/dev/null && sed -i '/GRUB_THEME=/d' /etc/default/grub
    echo "GRUB_THEME=\"${THEME_DIR}/${THEME_NAME}/theme.txt\"" >> /etc/default/grub
    echo "\n finalizing your installation .......\n \n."
    # Update grub config
    echo "Updating grub config..."
    if has_command update-grub; then
        update-grub
    elif has_command grub-mkconfig; then
        grub-mkconfig -o /boot/grub/grub.cfg
    elif has_command grub2-mkconfig; then
        if has_command zypper; then
            grub2-mkconfig -o /boot/grub2/grub.cfg
        elif has_command dnf; then
            grub2-mkconfig -o /boot/efi/EFI/fedora/grub.cfg
        fi
    fi
else
    echo "\n [ Error! ] -> Run me as root  \n \n "
fi